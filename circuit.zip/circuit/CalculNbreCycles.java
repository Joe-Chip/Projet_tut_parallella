package circuit;

import lilas.lmi.ExceptionObjetMateriel;
import lilas.lmi.ObjetMateriel;

public interface CalculNbreCycles extends ObjetMateriel {
	/**
	 * Permet d'arrêter un calcul en cours
	 */
	public void softReset() throws ExceptionObjetMateriel;
	
	/**
	 * Permet d'initialiser le nombre maximum d'itérations à effectuer
	 * @param nMax le nombre maximum d'itérations
	 * @param epsilon la précision pour comparer l'égalité entre deux nombres
	 */
	public void initNbrCyclesMax(int nMax, double epsilon) throws ExceptionObjetMateriel;
	
	/**
	 * Permet d'initialiser les valeurs initiales pour l'itération no iter
	 * @param iter numéro de l'itération
	 * @param val valeur initiale pour l'itération no iter
	 */
	public void initValeursInitiales(int iter, double val) throws ExceptionObjetMateriel;

	/**
	 * Permet d'initialiser une valeur initiale indépendante de l'itération
	 * @param val valeur initiale pour l'itération no iter
	 */
	public void initValeursInitiales(double val) throws ExceptionObjetMateriel;
	
	/**
	 * Permet d'effectuer la recherche d'un cycle au point (a,b)
	 * @param a
	 * @param b
	 * @return le cycle trouvé (0=pas de cyle, 1=cycle d'ordre 1, ...)
	 */
	public byte calcul(double a, double b) throws ExceptionObjetMateriel;
	
}
