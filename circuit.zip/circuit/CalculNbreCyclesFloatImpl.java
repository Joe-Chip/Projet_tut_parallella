package circuit;

import lilas.lmi.ExceptionObjetMateriel;

public class CalculNbreCyclesFloatImpl  implements CalculNbreCycles {
	float [] valeurInit;
	float a;
	float b;
	int m;
	byte ordreCycle;
	int noItérationCourante;
	int indiceItérationSuivante;
	int indiceItérationCourante;
	int indiceItérationPrécédente;
	int nMax;
	int mMax;
	boolean arrêtRunner;
	int ctrCalculs;

	float[][] lgN;
	int cycleMax = 4; // ordre max de cycles à détecter
	double epsilon;
	public int nombreLignes = 8; // il faut nombreLignes<cycleMax+2 et nbrlignes soit une puissance de 2 !
	public int masqueIndiceLigne = nombreLignes-1;
	
	public void softReset() throws ExceptionObjetMateriel {
		arrêtRunner = true;
	}
	
	public void initNbrCyclesMax(int max, double epsilon) throws ExceptionObjetMateriel {
		nMax = max;
		mMax = max;
		valeurInit = new float[mMax];
		lgN = new float[nombreLignes][mMax];
		this.epsilon = epsilon;
		arrêtRunner = false;
	}

	public void initValeursInitiales(int iter, double val) throws ExceptionObjetMateriel {
		valeurInit[iter] = (float) val;
	}

	public void initValeursInitiales(double val) throws ExceptionObjetMateriel {
		for (int i=0; i<mMax; i++) valeurInit[i] = (float) val;
	}

	private double foo(double valM1, double valM2) {
		return valM1 * valM1 + b * valM2 + a;
	}

	public byte calcul(double aa, double bb) throws ExceptionObjetMateriel {
		this.a = (float) aa;
		this.b = (float) bb;
		// initialisation itération 0
		for (int m=0; m<mMax; m++) lgN[0][m] = valeurInit[m];
		// itération 2..nMax
		indiceItérationCourante = 0;
		indiceItérationSuivante = 1;
		byte resultat = 0;
		for (int n=1; n<nMax; n++) {
			noItérationCourante = n;
			indiceItérationPrécédente= indiceItérationCourante;
			indiceItérationCourante =  indiceItérationSuivante;
			indiceItérationSuivante = (n+1) & masqueIndiceLigne;
			lgN[indiceItérationCourante][0] = valeurInit[n];
			for (int m=1; m<mMax; m++) {
				if (arrêtRunner) return 0;
				this.m = m;
				ctrCalculs++;
				//lgN[indiceItérationCourante][m] = fooRecur();
				float valM = lgN[indiceItérationPrécédente][m];
				float valMm1 = lgN[indiceItérationPrécédente][m-1];
				float valMnouveau = valM * valM + b * valMm1 + a; // foo(valM, valMm1);
				lgN[indiceItérationCourante][m] = valMnouveau;
				lgN[indiceItérationSuivante][m] = (valMnouveau + b) * valMnouveau + a;
				/*
				if (Math.abs(valM)!=(Double.POSITIVE_INFINITY)&&
						Math.abs(valMm1)!=(Double.POSITIVE_INFINITY)&&
						Math.abs(valMnouveau)==(Double.POSITIVE_INFINITY))
					return -1;//System.out.println("a="+a +" b="+b+" valM="+valM+" valMm1="+valMm1);
				*/
				//test des cycles
				if (Math.abs(lgN[indiceItérationCourante][m]-lgN[indiceItérationSuivante][m]) <= epsilon) {
					if (resultat==0) resultat = 1;//return 1;
				} else {
					for (int cycle=2; cycle<=cycleMax; cycle++) {
						if (m<cycle) break;
						if ((Math.abs(lgN[indiceItérationCourante][m]-lgN[(noItérationCourante-cycle) & masqueIndiceLigne][m]) <= epsilon) &&
								(Math.abs(lgN[indiceItérationCourante][m]-lgN[indiceItérationCourante][m-cycle]) <= epsilon)) {
							//return (byte) cycle;
							if (resultat==0 || resultat>cycle) resultat=(byte)cycle;
							break;
						}
					}
				}
			}
		}
		return resultat;
	}

}
