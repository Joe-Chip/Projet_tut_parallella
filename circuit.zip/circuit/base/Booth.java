package circuit.base;

public class Booth {
	long A;
	long B;
	public Booth(long A, long B) {
		this.A = A;
		this.B = B;
	}
	
	static long booth(long B, byte a2ip1, byte a2i, byte a2im1) throws Exception {
		byte a3b =  (byte) (a2ip1*4+a2i*2+a2im1);
		switch (a3b) {
		case 0 : return 0;
		case 1 : return B;
		case 2 : return B;
		case 3 : return 2*B;
		case 4 : return -2*B;
		case 5 : return -1 * B;
		case 6 : return -1 * B;
		case 7 : return 0;
		default : throw new Exception("Calcul impossible pour "+a3b);
		}
	}
	
	static long multiplier(long A, long B, byte a2im1) throws Exception {
		if (A==0 && a2im1==0) return 0;
		else if (A==0 && a2im1==0) return B;
		byte a2ip1 = (byte) ((A/2) % 2);
		byte a2i = (byte) (A % 2);
		return multiplier (A/4, B, a2ip1) *4 + booth(B, a2ip1, a2i, a2im1);
	}
	public static void main(String[] args) throws Exception {
		long A = Long.parseLong(args[0]);
		long B = Long.parseLong(args[1]);
		System.out.println(""+(A*B));
		System.out.println(""+multiplier(A, B, (byte)0));
	}

}
