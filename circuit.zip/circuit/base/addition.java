package circuit.base;

import java.util.Map;

import org.w3c.dom.Element;

import lilas.ExceptionLilas;
import lilas.ExceptionValeur;
import lilas.SystemeReactif;
import logique5E.ConnexionLogique;
import logique5E.ModuleJava;
import logique5E.ValeurLogique;

public class addition extends ModuleJava {
	ConnexionLogique P;
	ConnexionLogique A2;
	ConnexionLogique A1;
	ConnexionLogique S;
	ConnexionLogique rin;
	ConnexionLogique rout;
	long mskSigne;
	long mskVal;
	
	public void initialiserVariablesConnexion() {
		P = (ConnexionLogique) getConnexion("P");
		A2 = (ConnexionLogique) getConnexion("A2");
		A1 = (ConnexionLogique) getConnexion("A1");
		rin = (ConnexionLogique) getConnexion("rin");
		S = (ConnexionLogique) getConnexion("S");
		rout = (ConnexionLogique) getConnexion("rout");
	}

	public addition(SystemeReactif système, String préfixe, Element elXML, Map<String, String> lstParamModule)
			throws ExceptionLilas {
		super(système, préfixe, elXML, getAttributStringStatic(elXML, "nom", "", lstParamModule), lstParamModule);
	}

	public boolean initialisationTailleInitialeComplète() throws ExceptionValeur {
		mskSigne = 3;
		mskVal = 1;
		for (int i=0; i<S.getTailleSignal(); i++) {
			mskSigne = 2 * mskSigne;
			mskVal = 2 * mskVal;
		}
		System.out.println("====>"+Long.toHexString(mskSigne)+" "+Long.toHexString(mskVal));
		System.out.println("== S:"+S.getTailleSignal()+" P:"+P.getTailleSignal()+" A2:"+A2.getTailleSignal()+" A1:"+A1.getTailleSignal());
		return true;
	}
	
	protected void activer() {
		ValeurLogique resLog = null;
		ValeurLogique routLog = null;
		/*
		System.out.println("Execution de l'addition "+lanceur.getDate());
		System.out.println("  P=   "+P.getValeur());
		try {
		System.out.println(" A2=    "+A2.getValeur()+" "+r2.getValeur()+" "+A2.getValeur().toLongSigné()+" "+A2.getValeur().toString("binaire"));
		System.out.println(" A1=    "+A1.getValeur()+" "+r1.getValeur()+" "+A1.getValeur().toLongSigné()+" "+A1.getValeur().toString("binaire"));
		}  catch (ExceptionValeur e) {
			System.out.println("???????");
		}
		*/
		long res = 0;
		try {
			res = P.getValeur().toLongSigné()+A2.getValeur().toLongSigné()+A1.getValeur().toLongSigné()+rin.getValeur().toLong();
			routLog = new ValeurLogique(2, (res & mskSigne)>> S.getTailleSignal());
			resLog = new ValeurLogique(S.getTailleSignal(), res & (mskVal-1));
		} catch (ExceptionValeur e) {
			try {
				//System.out.println("====???===>"+Long.toHexString(res)+" "+Long.toHexString(mskSigne));
				//e.printStackTrace();
				resLog = new ValeurLogique(S.getTailleSignal(), ValeurLogique.ValeurBit.X);
				routLog = new ValeurLogique(2, ValeurLogique.ValeurBit.X);
			} catch (ExceptionValeur e1) {
				e1.printStackTrace();
			}
		}
		S.setValeur(this, 5000, resLog);
		rout.setValeur(this, 5000, routLog);
		System.out.println("  S= "+rout.getValeur()+" "+S.getValeur());
		System.out.println("============");
		/*
		*/
	}


}
